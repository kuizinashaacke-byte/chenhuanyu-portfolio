package com.shuqiananxin.app;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public final class MainActivity extends Activity {
    private static final int EXPORT_REQUEST = 42;
    private WebView webView;
    private String pendingExport;
    private FrameLayout container;
    private android.view.View fullscreenView;
    private WebChromeClient.CustomViewCallback fullscreenCallback;

    @Override
    public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(18, 92, 97));
        getWindow().setNavigationBarColor(Color.WHITE);
        container = new FrameLayout(this);
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(243, 247, 246));
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setAllowFileAccess(true);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setMediaPlaybackRequiresUserGesture(true);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.getSettings().setAllowFileAccessFromFileURLs(false);
        webView.getSettings().setAllowUniversalAccessFromFileURLs(false);
        webView.addJavascriptInterface(new ExportBridge(), "AndroidCare");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("file".equals(uri.getScheme()) && uri.toString().startsWith("file:///android_asset/www/")) {
                    return false;
                }
                if ("https".equals(uri.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
                    catch (Exception error) { Toast.makeText(MainActivity.this, "请在浏览器查看内容来源", Toast.LENGTH_SHORT).show(); }
                }
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onShowCustomView(android.view.View view, CustomViewCallback callback) {
                if (fullscreenView != null) { callback.onCustomViewHidden(); return; }
                fullscreenView = view;
                fullscreenCallback = callback;
                container.addView(view, new FrameLayout.LayoutParams(-1, -1));
                webView.setVisibility(android.view.View.GONE);
            }
            @Override
            public void onHideCustomView() { exitFullscreen(); }
        });
        container.addView(webView, new FrameLayout.LayoutParams(-1, -1));
        container.setOnApplyWindowInsetsListener((view, insets) -> {
            view.setPadding(insets.getSystemWindowInsetLeft(), insets.getSystemWindowInsetTop(), insets.getSystemWindowInsetRight(), insets.getSystemWindowInsetBottom());
            return insets.consumeSystemWindowInsets();
        });
        setContentView(container);
        webView.loadUrl("file:///android_asset/www/index.html");
    }

    private void exitFullscreen() {
        if (fullscreenView == null) return;
        container.removeView(fullscreenView);
        fullscreenView = null;
        webView.setVisibility(android.view.View.VISIBLE);
        if (fullscreenCallback != null) fullscreenCallback.onCustomViewHidden();
        fullscreenCallback = null;
    }

    @Override
    public void onBackPressed() {
        if (fullscreenView != null) { exitFullscreen(); return; }
        webView.evaluateJavascript("(function(){if(window.CareApp){var v=CareApp.view();if(v.page!=='home'&&v.page!=='nurse'){CareApp.navigate(v.role==='patient'?'home':'nurse');return true;}}return false;})()", value -> {
            if (!"true".equals(value)) super.onBackPressed();
        });
    }

    private final class ExportBridge {
        @JavascriptInterface
        public void saveText(String filename, String text) {
            if (text == null || text.length() > 2000000) return;
            runOnUiThread(() -> {
                if (pendingExport != null) return;
                pendingExport = text;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "previsit-demo.json");
                try { startActivityForResult(intent, EXPORT_REQUEST); }
                catch (Exception error) {
                    pendingExport = null;
                    Toast.makeText(MainActivity.this, "此设备暂时无法选择导出位置", Toast.LENGTH_LONG).show();
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != EXPORT_REQUEST) return;
        String text = pendingExport;
        pendingExport = null;
        if (resultCode != RESULT_OK || data == null || data.getData() == null || text == null) return;
        try (OutputStream output = getContentResolver().openOutputStream(data.getData())) {
            if (output == null) throw new java.io.IOException("Missing destination");
            output.write(text.getBytes(StandardCharsets.UTF_8));
            Toast.makeText(this, "演示记录已导出", Toast.LENGTH_SHORT).show();
        } catch (Exception error) {
            Toast.makeText(this, "导出失败，请重新选择保存位置", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onPause() { webView.onPause(); super.onPause(); }
    @Override
    protected void onResume() { super.onResume(); if (webView != null) webView.onResume(); }
    @Override
    protected void onDestroy() {
        webView.removeJavascriptInterface("AndroidCare");
        webView.destroy();
        super.onDestroy();
    }
}
