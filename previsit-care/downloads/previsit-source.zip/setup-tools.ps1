$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
$toolRoot = Join-Path $PSScriptRoot '.tools'
New-Item -ItemType Directory -Force -Path $toolRoot | Out-Null
$downloads = @(
    @{ Name='jdk'; Url='https://github.com/adoptium/temurin17-binaries/releases/download/jdk-17.0.21.1%2B2/OpenJDK17U-jdk_x64_windows_hotspot_17.0.21.1_2.zip'; Algorithm='SHA256'; Hash='eafba0944f777abdc74d5aad16049c9b5a1275b6ce99e2939ba9f7f3e6f08c87' },
    @{ Name='platform'; Url='https://dl.google.com/android/repository/platform-35_r02.zip'; Algorithm='SHA1'; Hash='0bb560a90a7a2cbd0dd8348224d518b638fe7949' },
    @{ Name='buildtools'; Url='https://dl.google.com/android/repository/build-tools_r35_windows.zip'; Algorithm='SHA1'; Hash='af059bb67cf7786f45ee0db85e2d24985df1b4b6' }
)
foreach ($item in $downloads) {
    $archive = Join-Path $toolRoot ($item.Name + '.zip')
    if (-not (Test-Path -LiteralPath $archive)) { Invoke-WebRequest -Uri $item.Url -OutFile $archive -TimeoutSec 300 }
    $hash = (Get-FileHash -LiteralPath $archive -Algorithm $item.Algorithm).Hash
    if ($hash -ne $item.Hash) { throw "Checksum mismatch for $($item.Name)" }
    $destination = Join-Path $toolRoot $item.Name
    if (-not (Test-Path -LiteralPath $destination)) { Expand-Archive -LiteralPath $archive -DestinationPath $destination }
    Write-Output "Ready: $($item.Name)"
}
