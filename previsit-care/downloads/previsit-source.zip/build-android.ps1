$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot
$javaRoot = (Get-ChildItem -LiteralPath "$root/.tools/jdk" -Directory | Select-Object -First 1).FullName
$tools = "$root/.tools/buildtools/android-15"
$androidJar = "$root/.tools/platform/android-35/android.jar"
$build = "$root/android/build"
New-Item -ItemType Directory -Force -Path "$build/classes", "$build/dex", "$build/assets/www", "$root/dist/downloads" | Out-Null
Copy-Item -Path "$root/dist/app/*" -Destination "$build/assets/www" -Recurse -Force

function Run-Tool([string]$exe, [string[]]$arguments) {
    & $exe @arguments
    if ($LASTEXITCODE -ne 0) { throw "Build failed in $exe with code $LASTEXITCODE" }
}

Run-Tool "$tools/aapt2.exe" @('compile','--dir',"$root/android/res",'-o',"$build/resources.zip")
Run-Tool "$tools/aapt2.exe" @('link','-o',"$build/base.apk",'-I',$androidJar,'--manifest',"$root/android/AndroidManifest.xml",'-A',"$build/assets",'--auto-add-overlay',"$build/resources.zip")
Run-Tool "$javaRoot/bin/javac.exe" @('-encoding','UTF-8','-source','8','-target','8','-classpath',$androidJar,'-d',"$build/classes", "$root/android/src/com/shuqiananxin/app/MainActivity.java")
$classes = @(Get-ChildItem -LiteralPath "$build/classes" -Recurse -Filter '*.class' | ForEach-Object { $_.FullName })
Run-Tool "$javaRoot/bin/java.exe" (@('-cp',"$tools/lib/d8.jar",'com.android.tools.r8.D8','--lib',$androidJar,'--min-api','26','--output',"$build/dex") + $classes)
Copy-Item -LiteralPath "$build/base.apk" -Destination "$build/unsigned.apk" -Force
Push-Location "$build/dex"
try { Run-Tool "$javaRoot/bin/jar.exe" @('uf',"$build/unsigned.apk",'classes.dex') } finally { Pop-Location }
Run-Tool "$tools/zipalign.exe" @('-f','4',"$build/unsigned.apk", "$build/aligned.apk")
$keystore = "$root/android/demo-signing.keystore"
if (-not (Test-Path -LiteralPath $keystore)) {
    Run-Tool "$javaRoot/bin/keytool.exe" @('-genkeypair','-keystore',$keystore,'-alias','demo','-keyalg','RSA','-keysize','2048','-validity','3650','-storepass','android','-keypass','android','-dname','CN=Previsit Course Demo, OU=Demo, O=Course, L=Beijing, ST=Beijing, C=CN')
}
Run-Tool "$javaRoot/bin/java.exe" @('-jar',"$tools/lib/apksigner.jar",'sign','--ks',$keystore,'--ks-key-alias','demo','--ks-pass','pass:android','--key-pass','pass:android','--out',"$root/dist/downloads/previsit-demo-v0.1.0.apk", "$build/aligned.apk")
Run-Tool "$javaRoot/bin/java.exe" @('-jar',"$tools/lib/apksigner.jar",'verify','--verbose',"$root/dist/downloads/previsit-demo-v0.1.0.apk")
Run-Tool "$tools/aapt2.exe" @('dump','badging',"$root/dist/downloads/previsit-demo-v0.1.0.apk")
